<?php include 'conn.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Sertifikat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

    <h2>Data Sertifikat</h2>
    <a href="tambah.php" class="btn btn-primary mb-3">+ Tambah</a>

    <div class="row">
        <?php
        $data = mysqli_query($conn, "SELECT * FROM sertifikat ORDER BY id DESC");

        while($row = mysqli_fetch_assoc($data)) {
        ?>
        <div class="col-md-4 mb-4">
            <div class="card">


    <?php echo "/minpro%20web/uploads/" . $row['gambar']; ?>
    <br>
    

                <img src="/minpro%20web/uploads/<?php echo $row['gambar']; ?>" width="100%"> 
                    height="200" 
                    style="object-fit:cover;"
                    onerror="this.src='https://via.placeholder.com/300x200?text=Error'">

                <div class="card-body">
                    <h5><?php echo $row['judul']; ?></h5>

                    <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="hapus.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm"
                    onclick="return confirm('Hapus?')">Hapus</a>
                </div>

            </div>
        </div>
        <?php } ?>
    </div>

</div>

</body>
</html>
<?php
$conn = mysqli_connect("localhost", "root", "", "portfolio_db");

if(isset($_POST['judul'])){

    $judul = $_POST['judul'];

    $file = $_FILES['gambar'];
    $nama = $file['name'];
    $tmp = $file['tmp_name'];

    // ambil ekstensi
    $ext = strtolower(pathinfo($nama, PATHINFO_EXTENSION));

    // validasi
    $allowed = ['jpg','jpeg','png'];

    if(!in_array($ext, $allowed)){
        echo "File harus gambar!";
        exit;
    }

    // rename file biar aman
    $namaBaru = uniqid() . '.' . $ext;

    // upload ke folder
    move_uploaded_file($tmp, "uploads/" . $namaBaru);

    // simpan ke database
    mysqli_query($conn, "INSERT INTO sertifikat (judul, gambar)
                        VALUES ('$judul', '$namaBaru')");

    header("Location: index.php");
}
?>
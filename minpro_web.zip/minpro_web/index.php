<?php
$conn = mysqli_connect("localhost", "root", "", "portfolio_db");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Portfolio | Maria Claudia Meo</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg fixed-top soft-nav">
<div class="container">
<a class="navbar-brand fw-semibold" onclick="goToSlide(0)">Maria Claudia</a>
<div class="navbar-nav ms-auto">
<a class="nav-link" onclick="goToSlide(0)">Home</a>
<a class="nav-link" onclick="goToSlide(1)">About</a>
<a class="nav-link" onclick="goToSlide(2)">Certificates</a>
</div>
</div>
</nav>

<!-- SLIDER -->
<div class="slider-wrapper">
<div class="slider" id="slider">

<!-- HOME -->
<section class="slide soft-hero">
<div class="container">
<div class="row align-items-center min-vh-100">
<div class="col-md-5 text-center mb-4">


<img src="http://minpro_web.test/uploads/profil.jpeg.jpeg" class="soft-photo">

</div>
<div class="col-md-7">
<h1 class="soft-name">Maria Claudia Meo</h1>
<p class="soft-role">
Mahasiswa Sistem Informasi<br>
Universitas Mulawarman<br>
Samarinda, Kalimantan Timur
</p>
<p class="soft-birth">Makassar, 19 Desember 2005</p>
<button class="soft-btn mt-3" onclick="goToSlide(1)">About Me</button>
</div>
</div>
</div>
</section>

<!-- ABOUT -->
<section class="slide soft-about">
<div class="container">
<h2 class="soft-title">About Me</h2>

<div class="row mt-4">

<div class="col-md-6 mb-4">
<div class="about-box">
<p>
Saya merupakan mahasiswa Sistem Informasi Universitas Mulawarman.
Sebelumnya saya bersekolah di SMK dan mengambil jurusan
Teknik Komputer dan Jaringan (TKJ).
</p>
<p>
Dari latar belakang tersebut, saya lumayan terbiasa menggunakan
komputer, serta tools desain sederhana.
</p>

<h5 class="mt-3">Pengalaman</h5>
<ul>
<li>Lulusan SMK jurusan Teknik Komputer dan Jaringan (TKJ)</li>
<li>Mengerjakan tugas berbasis komputer dan aplikasi digital</li>
</ul>
</div>
</div>

<div class="col-md-6 mb-4">
<div class="about-card">
<ul class="about-list">
<li><span>Nama</span>Maria Claudia Meo</li>
<li><span>TTL</span>Makassar, 19 Desember 2005</li>
<li><span>Status</span>Mahasiswa</li>
<li><span>Prodi</span>Sistem Informasi</li>
<li><span>Universitas</span>Universitas Mulawarman</li>
<li><span>Domisili</span>Samarinda</li>
</ul>
</div>
</div>

</div>

<!-- SKILLS -->
<div class="row mt-4">
<div class="col-md-8 mx-auto">
<h3 class="soft-title">Skills</h3>

<label>Canva</label>
<div class="progress mb-3">
<div class="progress-bar bg-pink" style="width: 85%">85%</div>
</div>

<label>CapCut</label>
<div class="progress mb-3">
<div class="progress-bar bg-pink" style="width: 80%">80%</div>
</div>

<label>Microsoft Word</label>
<div class="progress mb-3">
<div class="progress-bar bg-pink" style="width: 85%">85%</div>
</div>

<label>Microsoft Excel</label>
<div class="progress mb-3">
<div class="progress-bar bg-pink" style="width: 75%">75%</div>
</div>

<label>Meitu</label>
<div class="progress mb-3">
<div class="progress-bar bg-pink" style="width: 70%">70%</div>
</div>

</div>
</div>

<button class="soft-btn mt-3" onclick="goToSlide(2)">Lihat Sertifikat</button>
</div>
</section>

<!-- CERTIFICATES -->
<section class="slide soft-cert">
<div class="container">
<h2 class="soft-title">Certificates</h2>

<div class="row mt-4">

<?php
$data = mysqli_query($conn, "SELECT * FROM sertifikat");

while($row = mysqli_fetch_assoc($data)) {
?>
<div class="col-md-4 mb-4">
<div class="soft-card">


<img src="http://minpro_web.test/uploads/<?php echo $row['gambar']; ?>" 
    style="height:200px; object-fit:cover; width:100%;">
<h5><?php echo $row['judul']; ?></h5>

</div>
</div>
<?php } ?>

</div>

<button class="soft-btn mt-3" onclick="goToSlide(0)">Kembali ke Home</button>
</div>
</section>

</div>
</div>

<script>
function goToSlide(index) {
document.getElementById("slider").style.transform =
`translateX(-${index * 100}vw)`;
}
</script>

</body>
</html>
<?php include 'conn.php'; ?>

<?php
$id = $_GET['id'];

$data = mysqli_query($conn, "SELECT * FROM sertifikat WHERE id=$id");
$d = mysqli_fetch_assoc($data);

// hapus file
unlink("uploads/" . $d['gambar']);

// hapus database
mysqli_query($conn, "DELETE FROM sertifikat WHERE id=$id");

header("Location: sertifikat.php");
?>
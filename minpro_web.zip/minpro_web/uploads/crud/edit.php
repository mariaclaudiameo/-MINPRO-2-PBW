<?php include 'conn.php'; ?>

<?php
$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM sertifikat WHERE id=$id");
$d = mysqli_fetch_assoc($data);

if(isset($_POST['submit'])){

    $judul = $_POST['judul'];

    if($_FILES['gambar']['name'] != ""){

        $file = $_FILES['gambar'];
        $nama = $file['name'];
        $tmp = $file['tmp_name'];

        $ext = strtolower(pathinfo($nama, PATHINFO_EXTENSION));
        $namaBaru = uniqid() . '.' . $ext;

        move_uploaded_file($tmp, "uploads/" . $namaBaru);

        mysqli_query($conn, "UPDATE sertifikat 
                            SET judul='$judul', gambar='$namaBaru'
                            WHERE id=$id");

    } else {
        mysqli_query($conn, "UPDATE sertifikat 
                            SET judul='$judul'
                            WHERE id=$id");
    }

    header("Location: sertifikat.php");
}
?>

<!DOCTYPE html>
<html>
<body>

<h2>Edit Sertifikat</h2>

<form method="POST" enctype="multipart/form-data">
    <input type="text" name="judul" value="<?php echo $d['judul']; ?>"><br><br>

    <img src="/minpro_web/uploads/<?php echo $d['gambar']; ?>" width="150"><br><br>

    <input type="file" name="gambar"><br><br>
    <button name="submit">Update</button>
</form>

</body>
</html>
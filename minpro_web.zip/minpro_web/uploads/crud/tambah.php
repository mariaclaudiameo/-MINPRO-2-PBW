<?php include 'conn.php'; ?>

<?php
if(isset($_POST['submit'])){

    $judul = $_POST['judul'];

    $file = $_FILES['gambar'];
    $nama = $file['name'];
    $tmp = $file['tmp_name'];

    $ext = strtolower(pathinfo($nama, PATHINFO_EXTENSION));
    $namaBaru = uniqid() . '.' . $ext;

    move_uploaded_file($tmp, "uploads/" . $namaBaru);

    mysqli_query($conn, "INSERT INTO sertifikat (judul, gambar)
                        VALUES ('$judul', '$namaBaru')");

    header("Location: sertifikat.php");
}
?>

<!DOCTYPE html>
<html>
<head><title>Tambah</title></head>
<body>

<h2>Tambah Sertifikat</h2>

<form method="POST" enctype="multipart/form-data">
    <input type="text" name="judul" placeholder="Judul" required><br><br>
    <input type="file" name="gambar" required><br><br>
    <button name="submit">Simpan</button>
</form>

</body>
</html>